module.exports = {
  run(ed) {
    ed.DomComponents.clear();
    ed.CssComposer.clear();
  }
};
