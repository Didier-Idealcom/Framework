module.exports = {
  // Style prefix
  stylePrefix: 'cm-',

  inlineCss: false
};
