module.exports = {
  stylePrefix: 'mdl-',

  title: '',

  content: '',

  backdrop: true
};
