module.exports = require('backbone').View.extend({});
