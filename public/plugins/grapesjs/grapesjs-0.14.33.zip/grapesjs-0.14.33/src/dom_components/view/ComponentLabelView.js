module.exports = require('./ComponentLinkView').extend({});
