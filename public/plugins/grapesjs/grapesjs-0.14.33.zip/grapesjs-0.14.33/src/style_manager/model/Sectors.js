const Sector = require('./Sector');

module.exports = require('backbone').Collection.extend({
  model: Sector
});
