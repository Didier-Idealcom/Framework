module.exports = {
  textTags: ['br', 'b', 'i', 'u', 'a', 'ul', 'ol'],

  // Custom CSS parser
  parserCss: null,

  // Custom HTML parser
  parserHtml: null
};
